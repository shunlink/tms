/** POD (front + back) may be uploaded only after ops marks the trip delivered. */
export function canUploadTripPod(tripStatus: string | null | undefined): boolean {
  return tripStatus === "DELIVERED";
}

export const POD_UPLOAD_LOCKED_MESSAGE =
  "POD upload unlocks after this trip is marked as delivered. You can prepare photos until then.";
