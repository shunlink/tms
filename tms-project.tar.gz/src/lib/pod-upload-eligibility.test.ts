import { describe, expect, it } from "vitest";
import { canUploadTripPod } from "./pod-upload-eligibility";

describe("canUploadTripPod", () => {
  it("allows only DELIVERED", () => {
    expect(canUploadTripPod("DELIVERED")).toBe(true);
    expect(canUploadTripPod("IN_TRANSIT")).toBe(false);
    expect(canUploadTripPod("DISPATCHED")).toBe(false);
    expect(canUploadTripPod("PENDING")).toBe(false);
  });
});
