import "server-only";

export function ewayNicBaseUrl(): string {
  return (process.env.EWAY_API_BASE_URL ?? "").replace(/\/$/, "");
}

export function ewayNicClientId(): string | null {
  return process.env.EWAY_CLIENT_ID?.trim() || null;
}

export function ewayNicClientSecret(): string | null {
  return process.env.EWAY_CLIENT_SECRET?.trim() || null;
}

export function ewayNicGstin(): string | null {
  return process.env.EWAY_GSTIN?.trim() || null;
}

export function ewayNicUsername(): string | null {
  return process.env.EWAY_USERNAME?.trim() || null;
}

export function ewayNicPassword(): string | null {
  return process.env.EWAY_PASSWORD?.trim() || null;
}

export function ewayNicPublicKeyPem(): string | null {
  const raw = process.env.EWAY_PUBLIC_KEY?.trim();
  if (!raw) return null;
  return raw.includes("BEGIN PUBLIC KEY") ? raw : `-----BEGIN PUBLIC KEY-----\n${raw}\n-----END PUBLIC KEY-----`;
}

export function ewayNicStaticAuthToken(): string | null {
  return process.env.EWAY_AUTH_TOKEN?.trim() || null;
}

export function ewayNicStaticSekKeyBase64(): string | null {
  return process.env.EWAY_SEK_KEY_BASE64?.trim() || null;
}

export function ewayNicAuthPath(): string {
  const p = process.env.EWAY_AUTH_PATH?.trim();
  return p ? (p.startsWith("/") ? p : `/${p}`) : "/ewayapi/Authenticate";
}

export function ewayNicGetPath(): string {
  const p = process.env.EWAY_GET_PATH?.trim();
  return p ? (p.startsWith("/") ? p : `/${p}`) : "/ewayapi/GetEwayBill";
}

export function ewayNicTimeoutMs(): number {
  const raw = process.env.EWAY_TIMEOUT_MS;
  const n = raw ? Number.parseInt(raw, 10) : 30_000;
  return Number.isFinite(n) && n > 0 ? n : 30_000;
}

export function isNicEwayConfigured(): boolean {
  return Boolean(
    ewayNicBaseUrl() && ewayNicClientId() && ewayNicClientSecret() && ewayNicGstin()
  );
}
